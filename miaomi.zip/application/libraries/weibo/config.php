<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '1994141322' );
define( "WB_SKEY" , 'fdbe19efa1b7be3a2315869a90694411' );
define("Meters_ACCESS_TOKEN",'2.001GK8IDiPNxKCc566f0152aBgKEQE');
define( "WB_CALLBACK_URL" , 'http://localhost/mengmaolu/weibo/callback.php' );
