<!DTD HTML>
<html>
<head>
	<title>login</title>
</head>
<body>
	<form method="post">	
		<li>
			<label>ID</label>
			<input type="text" name="ID" />
		</li>
		<li>
			<label>UID</label>
			<input type="text" name="UID" />
		</li>
		<li>
			<label>Name</label>
			<input type="text" name="UNAME" />
		</li><li>
			<label>AVATAR</label>
			<input type="text" name="UAVA" />
		</li>
		<button>Submit</button>
	</form>


	
</body>
</html>