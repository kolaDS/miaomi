<form action="" method="post">
	<ul>
		<li>
			<label><?php echo("IMGID"); ?>:</label>
			<input name="comment_imgid" type="text" />
		</li>
		<li>
			<label>TEXT</label>
			<textarea name="comment_text"></textarea>
		</li>
		<li>
			<button type="submit">提交</button>
		</li>
	</ul>
</form>