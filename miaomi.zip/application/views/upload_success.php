<html>
<head>
	<meta charset="UTF-8" />
<title>Upload Form</title>
</head>
<body>

<h3>Your file was successfully uploaded!</h3>

<ul>
	<?php
	echo ("<li>".$imgtext."</li>");
	?>
<?php foreach ($imgdata['upload_data'] as $item => $value):?>
<li><?php echo $item;?>: <?php echo $value;?></li>
<?php endforeach; ?>
</ul>

<p><?php echo anchor('uploadcat', 'Upload Another File!'); ?></p>

</body>
</html>