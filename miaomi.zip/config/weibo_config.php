<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '1994141322' );
define( "WB_SKEY" , 'fdbe19efa1b7be3a2315869a90694411' );
define( "WB_CALLBACK_URL" , 'http://localhost/miaomi/index.php/callback' );
